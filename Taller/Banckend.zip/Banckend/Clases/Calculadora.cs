﻿

using CsharpIntroduction.Startup.Interfases;

namespace CsharpIntroduction.Startup.Clases
{
    internal class Calculadora : ICalculadora
    {


        public double Sumar(double a, double b) { return a + b; }
        public double Restar(double a, double b) { return a + b; }
        public double Multiplicar(double a, double b) { return a * b; }
        public double Dividir(double a, double b) { return a  / b; }

        }



 }
