﻿

namespace CsharpIntroduction.Startup.Option
{
    internal class Option
    {
        
		public int id { get; set; }
        public string name { get; set; }
    
}
}
